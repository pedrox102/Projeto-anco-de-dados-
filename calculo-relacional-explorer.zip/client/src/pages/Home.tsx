/**
 * Direção visual: Caderno de Consulta — página editorial técnica, de leitura guiada,
 * com papel mineral, azul de tinta e coral reservado a predicados e ações.
 */
import { useState } from "react";
import {
  ArrowDownRight,
  BookOpen,
  Braces,
  Check,
  ChevronRight,
  Code2,
  Database,
  ExternalLink,
  Filter,
  GitBranch,
  GraduationCap,
  Network,
  Printer,
  Share2,
  ShieldCheck,
  Sigma,
  Table2,
} from "lucide-react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  XAxis,
  YAxis,
} from "recharts";
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  type ChartConfig,
} from "@/components/ui/chart";
import { Button } from "@/components/ui/button";

const logoUrl = "/manus-storage/calculo-relacional-logo_8d850aeb.png";
const heroUrl = "/manus-storage/calculo-relacional-hero_14be2559.jpg";
const relationsUrl = "/manus-storage/calculo-relacional-relacoes_8f415814.jpg";
const safetyUrl = "/manus-storage/calculo-relacional-seguranca_1ac9e3c4.jpg";

type Example = {
  id: string;
  label: string;
  title: string;
  prompt: string;
  trc: string;
  drc: string;
  sql: string;
  insight: string;
  stages: { etapa: string; tuplas: number }[];
  columns: string[];
  rows: string[][];
};

const examples: Example[] = [
  {
    id: "filtro",
    label: "01 · filtro",
    title: "Alunos de Computação",
    prompt: "Quais alunos pertencem ao curso de Computação?",
    trc: "{ a | Aluno(a) ∧ a.curso = ‘Computação’ }",
    drc: "{ ⟨id, nome, curso⟩ | Aluno(id, nome, curso) ∧ curso = ‘Computação’ }",
    sql: "SELECT id_aluno, nome, curso\nFROM Aluno\nWHERE curso = 'Computação';",
    insight:
      "O predicado restringe a variável-tupla a registros de Aluno cujo atributo curso possui o valor solicitado.",
    stages: [
      { etapa: "Aluno", tuplas: 5 },
      { etapa: "Predicado", tuplas: 3 },
      { etapa: "Saída", tuplas: 3 },
    ],
    columns: ["id_aluno", "nome", "curso"],
    rows: [
      ["101", "Ana Souza", "Computação"],
      ["103", "Carla Reis", "Computação"],
      ["105", "Eva Costa", "Computação"],
    ],
  },
  {
    id: "juncao",
    label: "02 · junção",
    title: "Notas iguais ou superiores a 7",
    prompt: "Quais alunos obtiveram nota igual ou superior a 7 em uma disciplina?",
    trc: "{ ⟨a.nome, m.id_disciplina, m.nota⟩ | Aluno(a) ∧ Matricula(m) ∧ a.id_aluno = m.id_aluno ∧ m.nota ≥ 7 }",
    drc: "{ ⟨nome, disc, nota⟩ | ∃id, curso, sem (Aluno(id, nome, curso) ∧ Matricula(id, disc, sem, nota) ∧ nota ≥ 7) }",
    sql: "SELECT a.nome, m.id_disciplina, m.nota\nFROM Aluno a\nJOIN Matricula m ON m.id_aluno = a.id_aluno\nWHERE m.nota >= 7;",
    insight:
      "A igualdade entre identificadores conecta duas relações; a comparação de nota atua depois como condição lógica.",
    stages: [
      { etapa: "Aluno", tuplas: 5 },
      { etapa: "Matrícula", tuplas: 6 },
      { etapa: "Junção", tuplas: 6 },
      { etapa: "Nota ≥ 7", tuplas: 4 },
    ],
    columns: ["nome", "id_disciplina", "nota"],
    rows: [
      ["Ana Souza", "BD101", "8,5"],
      ["Bruno Lima", "BD101", "7,0"],
      ["Carla Reis", "BD203", "9,2"],
      ["Eva Costa", "BD101", "7,8"],
    ],
  },
  {
    id: "existe",
    label: "03 · existe",
    title: "Matrícula em 2026.1",
    prompt: "Quais alunos possuem pelo menos uma matrícula no semestre 2026.1?",
    trc: "{ a | Aluno(a) ∧ ∃m (Matricula(m) ∧ m.id_aluno = a.id_aluno ∧ m.semestre = ‘2026.1’) }",
    drc: "{ ⟨id, nome⟩ | Aluno(id, nome, curso) ∧ ∃disc, nota (Matricula(id, disc, ‘2026.1’, nota)) }",
    sql: "SELECT a.id_aluno, a.nome\nFROM Aluno a\nWHERE EXISTS (\n  SELECT 1 FROM Matricula m\n  WHERE m.id_aluno = a.id_aluno\n    AND m.semestre = '2026.1'\n);",
    insight:
      "O quantificador existencial devolve o aluno quando é possível encontrar ao menos uma matrícula relacionada que satisfaz o semestre.",
    stages: [
      { etapa: "Aluno", tuplas: 5 },
      { etapa: "Matrícula", tuplas: 6 },
      { etapa: "Semestre", tuplas: 4 },
      { etapa: "EXISTS", tuplas: 3 },
    ],
    columns: ["id_aluno", "nome"],
    rows: [
      ["101", "Ana Souza"],
      ["102", "Bruno Lima"],
      ["105", "Eva Costa"],
    ],
  },
  {
    id: "segura",
    label: "04 · segura",
    title: "Aprovado em todas as matrículas",
    prompt: "Quais alunos não possuem matrícula com nota abaixo de 7?",
    trc: "{ a | Aluno(a) ∧ ¬∃m (Matricula(m) ∧ m.id_aluno = a.id_aluno ∧ m.nota < 7) }",
    drc: "{ ⟨id, nome⟩ | Aluno(id, nome, curso) ∧ ¬∃disc, sem, nota (Matricula(id, disc, sem, nota) ∧ nota < 7) }",
    sql: "SELECT a.id_aluno, a.nome\nFROM Aluno a\nWHERE NOT EXISTS (\n  SELECT 1 FROM Matricula m\n  WHERE m.id_aluno = a.id_aluno\n    AND m.nota < 7\n);",
    insight:
      "A negação de um contraexemplo traduz a ideia universal: não existe matrícula do aluno que viole a condição de aprovação.",
    stages: [
      { etapa: "Aluno", tuplas: 5 },
      { etapa: "Matrícula", tuplas: 6 },
      { etapa: "Nota < 7", tuplas: 2 },
      { etapa: "Sem exceção", tuplas: 3 },
    ],
    columns: ["id_aluno", "nome"],
    rows: [
      ["101", "Ana Souza"],
      ["103", "Carla Reis"],
      ["105", "Eva Costa"],
    ],
  },
];

const chartConfig = {
  tuplas: {
    label: "Tuplas",
    color: "#E85D42",
  },
} satisfies ChartConfig;

const navItems = [
  ["01", "Fundamentos", "#fundamentos"],
  ["02", "Onde é utilizado", "#usos"],
  ["03", "Por que importa", "#importancia"],
  ["04", "Laboratório", "#laboratorio"],
  ["05", "Referências", "#referencias"],
];

const codeLabels = [
  ["trc", "Cálculo de Tuplas"],
  ["drc", "Cálculo de Domínio"],
  ["sql", "SQL equivalente"],
] as const;

const predicateLabels: Record<string, string> = {
  filtro: "curso = ‘Computação’",
  juncao: "a.id_aluno = m.id_aluno ∧ m.nota ≥ 7",
  existe: "∃m: m.semestre = ‘2026.1’",
  segura: "¬∃m: m.nota < 7",
};

export default function Home() {
  const [activeExample, setActiveExample] = useState(0);
  const [activeNotation, setActiveNotation] = useState<"trc" | "drc" | "sql">("trc");
  const [shareMessage, setShareMessage] = useState("");
  const example = examples[activeExample];

  const handleShare = async () => {
    const shareData = {
      title: "Cálculo Relacional — Explorer",
      text: "Pesquisa interativa sobre Cálculo Relacional",
      url: window.location.href,
    };

    try {
      if (navigator.share) {
        await navigator.share(shareData);
        setShareMessage("Página compartilhada.");
      } else {
        await navigator.clipboard.writeText(window.location.href);
        setShareMessage("Link copiado para a área de transferência.");
      }
    } catch {
      setShareMessage("Compartilhamento cancelado. A URL permanece disponível no navegador.");
    }
  };

  const notation = example[activeNotation];

  return (
    <div className="research-shell">
      <header className="topbar print:hidden">
        <a href="#topo" className="brand-mark" aria-label="Ir ao início">
          <img src={logoUrl} alt="Símbolo do Cálculo Relacional" className="brand-logo" />
          <span className="brand-wordmark">
            <strong>Cálculo</strong>
            <span>RELACIONAL</span>
          </span>
        </a>
        <div className="topbar-actions">
          <Button variant="ghost" onClick={handleShare} className="utility-button">
            <Share2 aria-hidden="true" /> Compartilhar
          </Button>
          <Button onClick={() => window.print()} className="print-button">
            <Printer aria-hidden="true" /> Salvar em PDF
          </Button>
        </div>
        {shareMessage ? <span className="share-message">{shareMessage}</span> : null}
      </header>

      <div id="topo" className="page-frame">
        <aside className="study-rail print:hidden" aria-label="Navegação do estudo">
          <div className="rail-head">
            <span className="eyebrow">Caderno · 01</span>
            <p>Uma leitura orientada por predicados, relações e resultados.</p>
          </div>
          <nav className="section-nav">
            {navItems.map(([number, label, href]) => (
              <a key={href} href={href}>
                <span>{number}</span>
                {label}
                <ChevronRight aria-hidden="true" />
              </a>
            ))}
          </nav>
          <div className="rail-note">
            <div className="rail-note-symbol">{`{ t | P(t) }`}</div>
            <p>Uma consulta descreve <strong>o que</strong> deve ser verdadeiro, não a sequência que produz a resposta.</p>
          </div>
        </aside>

        <main className="reading-canvas">
          <section className="hero-section" aria-labelledby="hero-title">
            <div className="hero-copy">
              <div className="label-row">
                <span className="section-chip"><Braces aria-hidden="true" /> Fundamentos de Banco de Dados</span>
                <span className="reading-time">Leitura guiada · 9 min</span>
              </div>
              <h1 id="hero-title">Formule a condição.<br />Observe as tuplas responderem.</h1>
              <p className="hero-lead">
                Cálculo Relacional é a linguagem formal que expressa consultas por meio de lógica: em vez de ensinar o banco <em>como</em> procurar, você define <em>quais</em> registros atendem à condição.
              </p>
              <div className="hero-actions print:hidden">
                <a className="ink-link" href="#laboratorio">
                  Abrir laboratório de consultas <ArrowDownRight aria-hidden="true" />
                </a>
                <a className="text-link" href="#referencias">Ver fontes utilizadas</a>
              </div>
            </div>
            <figure className="hero-figure">
              <img src={heroUrl} alt="Composição editorial abstrata com nós relacionais, chaves de conjunto e um predicado em coral" />
              <figcaption><span>fig. 01</span> Relações, restrições e resposta em uma mesma composição.</figcaption>
            </figure>
          </section>

          <section id="fundamentos" className="content-section conceptual-section" aria-labelledby="fundamentos-title">
            <div className="section-index">01</div>
            <div className="section-body">
              <div className="section-heading">
                <span className="eyebrow">Introdução</span>
                <h2 id="fundamentos-title">O resultado vem antes do caminho.</h2>
              </div>
              <div className="prose-columns">
                <p>
                  O cálculo relacional é uma linguagem de consulta <strong>declarativa e não procedural</strong>. Uma fórmula especifica um predicado; as tuplas ou os valores que tornam esse predicado verdadeiro constituem o resultado da consulta. A ideia deriva do cálculo de predicados e integra os fundamentos do modelo relacional.<sup><a href="#ref-2">[2]</a></sup><sup><a href="#ref-5">[5]</a></sup>
                </p>
                <p>
                  Há duas formas clássicas: o <strong>cálculo relacional de tuplas (TRC)</strong>, em que as variáveis representam linhas inteiras, e o <strong>cálculo relacional de domínio (DRC)</strong>, em que as variáveis representam valores de atributos. Ambos descrevem conjuntos de resposta por condições lógicas.<sup><a href="#ref-1">[1]</a></sup>
                </p>
              </div>
              <div className="definition-strip">
                <div>
                  <span className="formula-tag">FORMA GERAL</span>
                  <code>{`{ t | P(t) }`}</code>
                </div>
                <p><strong>t</strong> é uma variável-tupla; <strong>P(t)</strong> é o predicado que decide se a tupla pertence ao resultado.</p>
              </div>
              <div className="concept-grid">
                <article><Table2 aria-hidden="true" /><span>Relação</span><p>Conjunto de tuplas com o mesmo esquema, como a tabela <code>Aluno</code>.</p></article>
                <article><Network aria-hidden="true" /><span>Tupla</span><p>Uma ocorrência completa da relação, equivalente a uma linha.</p></article>
                <article><Sigma aria-hidden="true" /><span>Predicado</span><p>Fórmula lógica que filtra e relaciona os dados procurados.</p></article>
                <article><ShieldCheck aria-hidden="true" /><span>Segurança</span><p>Restrição que mantém a resposta finita e ligada ao banco.</p></article>
              </div>
            </div>
          </section>

          <section id="usos" className="content-section uses-section" aria-labelledby="usos-title">
            <div className="section-index">02</div>
            <div className="section-body">
              <div className="section-heading split-heading">
                <div>
                  <span className="eyebrow">Aplicação</span>
                  <h2 id="usos-title">Onde essa lógica aparece?</h2>
                </div>
                <p>O formalismo não é apenas uma notação de sala de aula: ele sustenta como consultas relacionais são compreendidas, comparadas e executadas.</p>
              </div>
              <div className="uses-layout">
                <div className="use-cards">
                  <article className="use-card accent-card"><Database aria-hidden="true" /><h3>SGBDs e SQL</h3><p>SQL traduz a intenção declarativa em consultas com <code>SELECT</code>, filtros, junções e subconsultas. A documentação histórica do PostgreSQL registra sua base no cálculo de tuplas.<sup><a href="#ref-4">[4]</a></sup></p></article>
                  <article className="use-card"><GitBranch aria-hidden="true" /><h3>Otimização</h3><p>Consultas logicamente equivalentes podem receber planos de execução distintos, preservando o resultado e buscando melhor desempenho.</p></article>
                  <article className="use-card"><GraduationCap aria-hidden="true" /><h3>Formação e teoria</h3><p>O cálculo conecta bancos de dados à lógica de predicados, à expressividade de linguagens e à verificação de consultas.</p></article>
                </div>
                <figure className="editorial-card">
                  <img src={relationsUrl} alt="Cartões abstratos de relações conectados por fios azuis a um predicado coral" />
                  <figcaption><span>TRC / DRC</span> Duas lentes para a mesma intenção de consulta.</figcaption>
                </figure>
              </div>
            </div>
          </section>

          <section id="importancia" className="content-section importance-section" aria-labelledby="importancia-title">
            <div className="section-index">03</div>
            <div className="section-body">
              <div className="section-heading">
                <span className="eyebrow">Importância</span>
                <h2 id="importancia-title">O que o estudo torna visível.</h2>
              </div>
              <div className="importance-layout">
                <div className="importance-list">
                  <article><span className="importance-no">A</span><div><h3>Abstração</h3><p>Separa a intenção da consulta do algoritmo usado para executá-la. Isso permite que o SGBD reorganize o plano sem mudar a resposta.</p></div></article>
                  <article><span className="importance-no">B</span><div><h3>Correção</h3><p>Predicados, variáveis e quantificadores tornam a pergunta verificável: fica mais claro que conjunto uma consulta deve retornar.</p></div></article>
                  <article><span className="importance-no">C</span><div><h3>Expressividade</h3><p>No fragmento seguro, cálculo e álgebra relacional possuem o mesmo poder expressivo — uma equivalência central para a teoria de consultas.<sup><a href="#ref-1">[1]</a></sup></p></div></article>
                </div>
                <article className="safety-card">
                  <img src={safetyUrl} alt="Ponto coral delimitado por uma fronteira azul em uma superfície de papel" />
                  <div className="safety-copy"><span className="formula-tag">CONSULTA SEGURA</span><h3>Uma resposta deve pertencer ao universo que a base conhece.</h3><p>Segurança impede fórmulas que produziriam valores arbitrários ou resultados infinitos fora dos dados relevantes.<sup><a href="#ref-5">[5]</a></sup></p></div>
                </article>
              </div>
            </div>
          </section>

          <section id="laboratorio" className="lab-section" aria-labelledby="laboratorio-title">
            <div className="lab-kicker"><span>04</span><span>Laboratório didático</span></div>
            <div className="lab-headline">
              <div>
                <h2 id="laboratorio-title">Leia a fórmula.<br />Veja o conjunto mudar.</h2>
                <p>Os dados abaixo são um conjunto didático. Escolha um cenário e acompanhe como a condição reduz ou relaciona tuplas.</p>
              </div>
              <div className="lab-plate-note"><span className="brace-signature">{`{ ● ● ● }`}</span><span><Filter aria-hidden="true" /> Placa de consulta anotada</span></div>
            </div>

            <div className="example-selector" role="tablist" aria-label="Exemplos de consulta">
              {examples.map((item, index) => (
                <button
                  key={item.id}
                  type="button"
                  role="tab"
                  aria-selected={activeExample === index}
                  className={activeExample === index ? "active" : ""}
                  onClick={() => {
                    setActiveExample(index);
                    setActiveNotation("trc");
                  }}
                >
                  {item.label}
                </button>
              ))}
            </div>

            <div className="query-lab">
              <div className="predicate-connector" aria-hidden="true"><span>P(t)</span><i /><span>R</span></div>
              <div className="query-panel">
                <div className="question-line"><span>Questão</span><p>{example.prompt}</p></div>
                <h3>{example.title}</h3>
                <div className="active-predicate"><span>PREDICADO ATIVO</span><code>{predicateLabels[example.id]}</code></div>
                <div className="notation-tabs" role="tablist" aria-label="Notações da consulta">
                  {codeLabels.map(([key, label]) => (
                    <button
                      key={key}
                      type="button"
                      role="tab"
                      aria-selected={activeNotation === key}
                      className={activeNotation === key ? "active" : ""}
                      onClick={() => setActiveNotation(key)}
                    >
                      {label}
                    </button>
                  ))}
                </div>
                <pre className={`code-block notation-${activeNotation}`}><code>{notation}</code></pre>
                <div className="insight-box"><Check aria-hidden="true" /><p>{example.insight}</p></div>
              </div>

              <div className="result-panel">
                <div className="result-label"><span className="status-dot" /> Resposta do predicado</div>
                <div className="result-table-wrap">
                  <table>
                    <thead><tr>{example.columns.map(column => <th key={column}>{column}</th>)}</tr></thead>
                    <tbody>{example.rows.map((row, rowIndex) => <tr key={`${example.id}-${rowIndex}`}>{row.map(cell => <td key={cell}>{cell}</td>)}</tr>)}</tbody>
                  </table>
                </div>
                <p className="result-caption"><strong>{example.rows.length} tuplas</strong> satisfazem a condição no conjunto didático.</p>
              </div>
            </div>

            <div className="chart-card">
              <div className="chart-copy"><span className="eyebrow">Visualização de execução</span><h3>Do conjunto de entrada ao resultado.</h3><p>O gráfico representa as cardinalidades do exemplo didático selecionado; não é uma métrica de desempenho de um SGBD.</p></div>
              <ChartContainer config={chartConfig} className="tuple-chart" aria-label="Gráfico de barras das tuplas por etapa da consulta">
                <BarChart data={example.stages} margin={{ top: 6, right: 6, left: -24, bottom: 0 }}>
                  <CartesianGrid vertical={false} stroke="#D8D0C1" strokeDasharray="3 5" />
                  <XAxis dataKey="etapa" tickLine={false} axisLine={false} tickMargin={10} />
                  <YAxis allowDecimals={false} tickLine={false} axisLine={false} />
                  <ChartTooltip cursor={{ fill: "#EAE4D8" }} content={<ChartTooltipContent hideLabel />} />
                  <Bar dataKey="tuplas" fill="var(--color-tuplas)" radius={[2, 2, 0, 0]} maxBarSize={44} />
                </BarChart>
              </ChartContainer>
            </div>
          </section>

          <section className="comparison-section" aria-labelledby="comparacao-title">
            <div className="notebook-margin"><span className="margin-disk">04.1</span><div className="margin-motif"><b>{`{`}</b><i /><i /><i /><b>{`}`}</b></div><span>Equivalência no fragmento seguro</span></div>
            <div className="section-heading"><span className="eyebrow">Comparação</span><h2 id="comparacao-title">Mesma pergunta, perspectivas diferentes.</h2></div>
            <div className="comparison-table-wrap">
              <table className="comparison-table">
                <thead><tr><th>Aspecto</th><th>Cálculo Relacional</th><th>Álgebra Relacional</th></tr></thead>
                <tbody>
                  <tr><th>Foco</th><td>Propriedades que o resultado deve satisfazer.</td><td>Operações que constroem o resultado.</td></tr>
                  <tr><th>Estilo</th><td>Declarativo, não procedural.</td><td>Procedural no nível dos operadores.</td></tr>
                  <tr><th>Unidade</th><td>Tuplas inteiras ou valores de domínio.</td><td>Relações intermediárias.</td></tr>
                  <tr><th>Expressividade</th><td colSpan={2}>Equivalentes no fragmento relacional seguro.<sup><a href="#ref-1">[1]</a></sup></td></tr>
                </tbody>
              </table>
            </div>
          </section>

          <section className="conclusion-section" aria-labelledby="conclusao-title">
            <div className="conclusion-number"><span>05</span><b>{`{`}</b><i /><i /><i /><b>{`}`}</b></div>
            <div><span className="eyebrow">Conclusão</span><h2 id="conclusao-title">Uma base lógica para consultas mais claras.</h2><p>O Cálculo Relacional ensina a descrever resultados por condições, não por roteiros de execução. Ao compreender tuplas, domínios, predicados, quantificadores e segurança, torna-se mais fácil interpretar a lógica que sustenta consultas em SQL e a transformação de dados em SGBDs relacionais.</p></div>
            <a className="conclusion-link print:hidden" href="#laboratorio">Retornar ao laboratório <ArrowDownRight aria-hidden="true" /></a>
          </section>

          <footer id="referencias" className="references" aria-labelledby="referencias-title">
            <div className="reference-register"><span>Registro de fontes</span><div><b>{`{`}</b><i /><i /><i /><b>{`}`}</b></div><span>06</span></div>
            <div className="references-heading"><BookOpen aria-hidden="true" /><div><span className="eyebrow">Pesquisa</span><h2 id="referencias-title">Referências bibliográficas</h2></div></div>
            <ol>
              <li id="ref-1">PALERMO, Giselle; BACARIN, Evandro. <em>Álgebra e Cálculo Relacional</em>. Instituto de Computação, Unicamp, 2005. <a href="https://www.ic.unicamp.br/~geovane/mo410-091/Ch04-Resumo.pdf" target="_blank" rel="noreferrer">Abrir fonte <ExternalLink aria-hidden="true" /></a></li>
              <li id="ref-2">UNIVERSIDADE FEDERAL DE SANTA CATARINA. <em>Cálculo Relacional</em>. Material didático da disciplina INE5323. <a href="https://www.inf.ufsc.br/~r.mello/ine5323/4-calculo.pdf" target="_blank" rel="noreferrer">Abrir fonte <ExternalLink aria-hidden="true" /></a></li>
              <li id="ref-3">CODD, Edgar F. <em>A relational model of data for large shared data banks</em>. Communications of the ACM, v. 13, n. 6, p. 377–387, 1970. DOI: <a href="https://doi.org/10.1145/362384.362685" target="_blank" rel="noreferrer">10.1145/362384.362685 <ExternalLink aria-hidden="true" /></a></li>
              <li id="ref-4">POSTGRESQL GLOBAL DEVELOPMENT GROUP. <em>The SQL Language</em>. PostgreSQL 7.1 Documentation. <a href="https://www.postgresql.org/docs/7.1/sql-language.html" target="_blank" rel="noreferrer">Abrir fonte <ExternalLink aria-hidden="true" /></a></li>
              <li id="ref-5">GORDON COLLEGE. <em>CS352 Lecture — Relational Calculus; QBE</em>. Revisado em 2023. <a href="https://www.math-cs.gordon.edu/courses/cps352/lectures-2023/Relational%20Calculus;%20QBE.pdf" target="_blank" rel="noreferrer">Abrir fonte <ExternalLink aria-hidden="true" /></a></li>
              <li id="ref-6">POSTGRESQL GLOBAL DEVELOPMENT GROUP. <em>SELECT</em>. PostgreSQL 18 Documentation. <a href="https://www.postgresql.org/docs/current/sql-select.html" target="_blank" rel="noreferrer">Abrir fonte <ExternalLink aria-hidden="true" /></a></li>
            </ol>
            <div className="footer-meta"><span>Pesquisa e interface didática</span><span>Manus AI · 2026</span></div>
          </footer>
        </main>
      </div>
    </div>
  );
}
